import { Typography } from "@mui/material";

export const Loading = () => {
    return <Typography variant="h6">Authentication in progress...</Typography>
}